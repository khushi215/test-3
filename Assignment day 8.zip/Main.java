
public class Main {
     
	public static void main(String[] args) {
		
		Employee employee=new Employee();
		Pilot p[]=new Pilot[3];
		for(int i=0;i<3;i++) {
			p[i]=new Pilot();
			p[i].getdetails();
			p[i].displaydetails();
			p[i].analysingflightplans();
		}
		
		
		Engineer engineer[]=new Engineer[3];
		for(int i=0;i<3;i++) {
			engineer[i]=new Engineer();
			engineer[i].getdetails();
			engineer[i].displaydetails();
			engineer[i].design();
		}
		
		
		Doctor doctor[]=new Doctor[3];
		for(int i=0;i<3;i++) {
			doctor[i]=new Doctor();
			doctor[i].getdetails();
			doctor[i].displaydetails();
			doctor[i].Monitoringpatients();
		}
	}
}
