import java.util.Scanner;
public class Pilot extends Employee {
   
   Scanner sc=new Scanner(System.in);
   String info;
   public void analysingflightplans() {
	   System.out.println("Enter information");
	   info=sc.next();
	   System.out.println("The information of the patient is: "+info);
   }
}
