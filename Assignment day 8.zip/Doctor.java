import java.util.Scanner;
public class Doctor extends Employee {
   
	Scanner sc=new Scanner(System.in);
	String patientinfo,medicalprescribtion;
	
	public void Monitoringpatients() {
		
		System.out.println("Enter information of the patients");
		patientinfo=sc.next();
		System.out.println("The information of the patient is: "+patientinfo);
	}
	
	public void prescribingmedication() {
		
		System.out.println("Prescribing the medication for the issues they are suffering");
		medicalprescribtion=sc.next();
		System.out.println("The prescribtion for the patient is: "+medicalprescribtion);
	}
}
