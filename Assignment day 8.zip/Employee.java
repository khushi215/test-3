import java.util.Scanner;
public class Employee {
	
   Scanner sc=new Scanner(System.in);
   
   String name,designation;
   int age;
   float salary;
   
   public void getdetails() {
	  System.out.println("Enter name,age,designation and salary");
	  name=sc.next();
	  age=sc.nextInt();
	  designation=sc.next();
	  salary=sc.nextFloat();
   }
   
   public void displaydetails() {
	   System.out.println(name+ " " +age);
	   System.out.println("The salary of "+name+" is: and the designation is: "+designation);
   }
}
