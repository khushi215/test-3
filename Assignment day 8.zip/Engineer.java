import java.util.Scanner;
public class Engineer extends Employee {
	Scanner sc=new Scanner(System.in);
	String productname;
	public void design() {
		
		System.out.println("Enter the product as per the customer requirements ");
		productname=sc.next();
		System.out.println("The name of the product is: "+productname);
	}
}
