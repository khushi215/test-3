package practicecoding;
class avenger{
	String name,weapon,planet,power, age;
	 public void getdetails(String name,String age,String power,String weapon,String planet) {
		 this.name=name;
		 this.age=age;
		 this.power=power;
		 this.weapon=weapon;
		 this.planet=planet;
		
	}
	public void displaydetails() {
		System.out.println("name is:"+name);
		System.out.println("age is:"+age);
		System.out.println("power is:"+power);
		System.out.println("weapon is:"+weapon);
		System.out.println("planet is:"+planet);
		
	
	}
}
public class avengerdetails {
	public static void main(String[] args) {
	avenger avng[]=new avenger[5];
	
	avng[0]=new avenger();
	avng[0].getdetails("Iron Man", "28","Strength and ability to fly", "Unibeam", "Earth");
	avng[0].displaydetails();
	avng[1]=new avenger();
	avng[1].getdetails("Thonas","29","Strength,stamina and speed","Double Edged Sword","planet 0259-S");
	avng[1].displaydetails();
	avng[2]=new avenger();
	avng[2].getdetails("Captain America", "39", "agility and speed", "Shield", "Earth");
	avng[2].displaydetails();
	avng[3]=new avenger();
	avng[3].getdetails("Black Panther","32","stamina and healing","anti-metal claws","planet Bast");
	avng[3].displaydetails();
	avng[4]=new avenger();
	avng[4].getdetails("Hulk", "34", "physical strength", "mjolnir","planet hulk");
	avng[4].displaydetails();
}
}


