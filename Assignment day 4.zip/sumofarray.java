package practicecoding;
import java.util.*;
public class sumofarray {
public static void main(String[] args) {
	int sum=0;
	int b[]=new int[5];
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the values:");
	for(int i=0;i<5;i++) {
		b[i]=sc.nextInt();
		sum=sum+b[i];
	}
	System.out.println("The sum is:"+sum);
}
}
