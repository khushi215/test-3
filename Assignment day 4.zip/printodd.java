package practicecoding;

public class printodd {
	public static void main(String[] args) {
		int[] a= {5,7,8,10,11};
	for(int i=0;i<5;i++) {
		if(a[i]%2==0) 
		continue;
		else {
			System.out.println("odd value is:"+a[i]);
		}
}
	}
}
