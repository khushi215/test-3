import java.util.Scanner;
public class Question {
  Scanner sc=new Scanner(System.in);	
  String question,optn1,optn2,optn3,optn4;
  int userans,correctans;
  
  public boolean askquestion() {
	 System.out.println(question);
	 System.out.println("1. "+optn1);
	 System.out.println("2. "+optn2);
	 System.out.println("3. "+optn3);
	 System.out.println("4. "+optn4);
	 userans=sc.nextInt();
	 if(userans==correctans) {
		return true; 
	 }
	 return false;
	 }
}
