
public class Game {
  Question question[]=new Question[3];	
  Player player=new Player();
  
  public void initgame() {
	  
	for(int i=0;i<3;i++) {
		question[i]=new Question();
		}
	question[0].question="What is the Capital of Canada ?";
	question[0].optn1="London";
	question[0].optn2="Ottawa";
	question[0].optn3="Delhi";
	question[0].optn4="Singapore";
	question[0].correctans=2;
	
	question[1].question="Who wrote the book,The Game Goes On ? ";
	question[1].optn1="Sheksphere";
	question[1].optn2="Govind";
	question[1].optn3="Alan Mc Gilvray";
	question[1].optn4="Balachandran";
	question[1].correctans=3;
	
	question[2].question="Who directed the film Daughter ?";
	question[2].optn1="Sammir";
	question[2].optn2="Reza Mirkarimi";
	question[2].optn3="Nitesh Tiwari";
	question[2].optn4="Subhash Kapoor";
	question[2].correctans=2;
	
  }
  
  public void play() {
	player.getdetails();
	for(int i=0;i<3;i++) {
		boolean status=question[i].askquestion();
		if(status==true) {
			player.score++;
			System.out.println("Excellent...! Well done.");
		}
		else {
			System.out.println("OOPS!!!");
		}
  }
	System.out.println(player.name+" ,your score is :  "+player.score);
}
}

